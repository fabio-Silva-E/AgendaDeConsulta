export class Medico{
    public Codigo!: number;
    public Nome: string;
    public DataNascimento: string;
    public CRM: string;

    constructor(){
        this.Nome = "";
        this.DataNascimento = "";
        this.CRM = "";
    }
}